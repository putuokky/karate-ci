<!-- Default box -->
<div class="row">
    <!-- /.col -->
    <div class="col-lg-12">
        <img src="<?= base_url("assets/dist/img/"); ?>banner karate.png" class="img-fluid" alt="Responsive image">
    </div>
    <!-- /.col -->
</div>
<br>